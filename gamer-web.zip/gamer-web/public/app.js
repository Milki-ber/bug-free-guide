let token = null;

function setStatus(msg) {
  document.getElementById('status').textContent = msg;
}

async function api(path, opts = {}) {
  const headers = { 'Content-Type': 'application/json', ...(opts.headers || {}) };
  if (token) headers.Authorization = `Bearer ${token}`;
  const res = await fetch(path, { ...opts, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `request failed (${res.status})`);
  return data;
}

async function register() {
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;
  try {
    await api('/api/auth/register', { method: 'POST', body: JSON.stringify({ username, password }) });
    setStatus(`Registered "${username}". Now log in.`);
  } catch (e) {
    setStatus(`Error: ${e.message}`);
  }
}

async function login() {
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;
  try {
    const data = await api('/api/auth/login', { method: 'POST', body: JSON.stringify({ username, password }) });
    token = data.token;
    setStatus(`Logged in as ${username}.`);
  } catch (e) {
    setStatus(`Error: ${e.message}`);
  }
}

async function submitScore() {
  const score = Number(document.getElementById('score').value);
  try {
    await api('/api/leaderboard/submit', { method: 'POST', body: JSON.stringify({ score }) });
    setStatus('Score submitted.');
    loadLeaderboard();
  } catch (e) {
    setStatus(`Error: ${e.message}`);
  }
}

async function loadLeaderboard() {
  const rows = await api('/api/leaderboard');
  const body = document.getElementById('leaderboard-body');
  body.innerHTML = rows
    .map((r, i) => `<tr><td>${i + 1}</td><td>${r.username}</td><td>${r.score}</td></tr>`)
    .join('');
}

async function queueUp() {
  try {
    const data = await api('/api/match/queue', { method: 'POST' });
    document.getElementById('match-result').textContent = JSON.stringify(data);
  } catch (e) {
    setStatus(`Error: ${e.message}`);
  }
}

loadLeaderboard();
