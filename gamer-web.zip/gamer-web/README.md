# Gamer web demo

Minimal implementation of the architecture diagram: browser -> CDN/frontend (static files) -> API gateway -> auth / game server (matchmaking) / database (in-memory).

## Run it

```bash
npm install
npm start
```

Then open http://localhost:3000

## What's included

- `server.js` — Express app acting as the API gateway. Routes to:
  - **Auth service**: `POST /api/auth/register`, `POST /api/auth/login` (JWT-based)
  - **Database**: in-memory `Map`/array — swap for Postgres, MySQL, or SQLite in production
  - **Leaderboard**: `GET /api/leaderboard`, `POST /api/leaderboard/submit`
  - **Game server (matchmaking stub)**: `POST /api/match/queue`, `GET /api/match/queue/status`
- `public/` — static frontend (served as the "CDN/frontend" layer) with a simple UI for registering, logging in, submitting scores, and joining the match queue.

## Notes / next steps for production

- Replace the in-memory `db` object with a real database and connection pooling.
- Move JWT_SECRET to a proper secrets manager; never hardcode it.
- Put a real CDN (Cloudflare, CloudFront) in front of `public/` and serve it from object storage rather than the app server.
- Replace the matchmaking stub with a real game server (e.g. authoritative WebSocket server, or a dedicated service like Agones/PlayFab) once you need live gameplay rather than turn-based/score submission.
