// server.js
// API gateway + auth service + game server (matchmaking) + database (in-memory)
// Matches the architecture: Browser -> CDN/frontend -> API gateway -> {auth, game server, database}

const express = require('express');
const path = require('path');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public'))); // serves the "CDN/frontend" layer

// ---------- "Database" (in-memory for demo; swap for Postgres/SQLite in production) ----------
const db = {
  users: new Map(),        // username -> { username, passwordHash, salt, rating }
  leaderboard: [],         // [{ username, score }]
  matchQueue: [],          // usernames waiting for a match
};

function hashPassword(password, salt) {
  return crypto.scryptSync(password, salt, 64).toString('hex');
}

// ---------- Auth middleware ----------
function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'missing token' });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'invalid or expired token' });
  }
}

// ---------- Auth service ----------
app.post('/api/auth/register', (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password || password.length < 6) {
    return res.status(400).json({ error: 'username and password (min 6 chars) required' });
  }
  if (db.users.has(username)) {
    return res.status(409).json({ error: 'username already taken' });
  }
  const salt = crypto.randomBytes(16).toString('hex');
  db.users.set(username, {
    username,
    passwordHash: hashPassword(password, salt),
    salt,
    rating: 1000,
  });
  res.status(201).json({ message: 'registered', username });
});

app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body || {};
  const user = db.users.get(username);
  if (!user || hashPassword(password, user.salt) !== user.passwordHash) {
    return res.status(401).json({ error: 'invalid credentials' });
  }
  const token = jwt.sign({ username }, JWT_SECRET, { expiresIn: '2h' });
  res.json({ token, expiresIn: '2h' });
});

// ---------- Leaderboard (reads/writes the "database") ----------
app.get('/api/leaderboard', (req, res) => {
  const top = [...db.leaderboard]
    .sort((a, b) => b.score - a.score)
    .slice(0, 20);
  res.json(top);
});

app.post('/api/leaderboard/submit', requireAuth, (req, res) => {
  const { score } = req.body || {};
  if (typeof score !== 'number') return res.status(400).json({ error: 'numeric score required' });
  db.leaderboard.push({ username: req.user.username, score, at: Date.now() });
  res.status(201).json({ message: 'score submitted' });
});

// ---------- Game server: matchmaking stub ----------
app.post('/api/match/queue', requireAuth, (req, res) => {
  if (!db.matchQueue.includes(req.user.username)) {
    db.matchQueue.push(req.user.username);
  }
  if (db.matchQueue.length >= 2) {
    const [p1, p2] = db.matchQueue.splice(0, 2);
    return res.json({ status: 'matched', matchId: crypto.randomUUID(), players: [p1, p2] });
  }
  res.json({ status: 'queued', position: db.matchQueue.length });
});

app.get('/api/match/queue/status', requireAuth, (req, res) => {
  res.json({ queueLength: db.matchQueue.length, inQueue: db.matchQueue.includes(req.user.username) });
});

app.listen(PORT, () => {
  console.log(`API gateway listening on http://localhost:${PORT}`);
});
